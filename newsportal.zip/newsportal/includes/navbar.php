<div class="navbar">
	<div class="logo_div">
		<a href="index.php"><img src="http://localhost/complete-blog-php/static/images/codesense.png"  height="100" width="300">
</a>
	</div>
	<ul>
	  <li><a class="zoom" href="index.php" >Home</a></li>
	  <li><a class="zoom" href="#news">News</a></li>
	  <li><a class="zoom" href="#contact">Contact</a></li>
	  <li><a class="zoom" href="#about">About</a></li>
	</ul>
</div>
